package edu.depaul.drinkspecials;

import android.app.Activity;
import android.util.Log;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.UnknownHostException;

public class Client extends Activity implements Runnable {
    private static final String TAG = "";
    private static final int SERVERPORT = 4444;
    private static final String SERVER_IP = "10.0.0.3";
    private static String test = "TESTING";
    public static PrintWriter out = null;
    public static BufferedReader in = null;

    public Client(String t){
        test=t;
    }

    @Override
    public void run() {
        try {
            Socket client = new Socket(SERVER_IP, SERVERPORT);
            out = new PrintWriter(new BufferedWriter(new OutputStreamWriter(client.getOutputStream())),true);
            in = new BufferedReader(new InputStreamReader(client.getInputStream()));

             out.println(test);
             Log.e(TAG, "SENT message to server: " + test);
             //Toast.makeText(getApplicationContext(), "sent message to server: " + test, Toast.LENGTH_LONG).show();

             String inputLine = null;
             inputLine = in.readLine();
             Log.e(TAG, "RECEIVED message from server: " + inputLine);
             //Toast.makeText(getApplicationContext(), inputLine + "':Was read from the server.'", Toast.LENGTH_SHORT).show();

             out.flush();
             out.close();
             in.close();

             client.close();

        } catch (UnknownHostException e) {
            Log.e(TAG, e + "-Unknown Host: " + SERVER_IP);
            e.printStackTrace();
        } catch (IOException e) {
            Log.e(TAG, e + "-Couldn't get I/O for the connection to " + SERVER_IP);
            e.printStackTrace();
        } catch (Exception e) {
            Log.e(TAG, e + "-EXCEPTION " + SERVER_IP + SERVERPORT);
            e.printStackTrace();
        }
    }
}