package edu.depaul.drinkspecials;

import android.os.Bundle;
import android.support.v7.app.ActionBarActivity;

/**
 * Created by OZ on 3/27/2015.
 */
public class MainActivity extends ActionBarActivity {

    @Override
    protected void  onCreate(Bundle saveInstanceState){
        super.onCreate(saveInstanceState);
        setContentView(R.layout.activity_map);

    }

}
